@echo off
REM ── One-time setup: lets the website's "Start engine" button launch this app ──
REM Registers a custom URL protocol (bdchygiene://) for the CURRENT USER only
REM (no admin rights needed). Point it at this folder's launcher.
setlocal
set "TARGET=%~dp0Start Hygiene App.bat"

reg add "HKCU\Software\Classes\bdchygiene" /ve /t REG_SZ /d "URL:BDC Hygiene Launcher" /f >nul
reg add "HKCU\Software\Classes\bdchygiene" /v "URL Protocol" /t REG_SZ /d "" /f >nul
reg add "HKCU\Software\Classes\bdchygiene\shell\open\command" /ve /t REG_SZ /d "\"%TARGET%\" \"%%1\"" /f >nul

echo.
echo   Registered successfully.
echo   The green "Start engine" button on the website can now launch this app.
echo   (Run this once. If you MOVE this folder, run it again.)
echo.
pause
