import asyncio, re, sys
try: sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception: pass
from playwright.async_api import async_playwright

URL = "https://admin.booking.com/fresa/extranet/policy_page/get_groups?hotel_id={h}&lang=xu&ses={s}"

async def main():
    async with async_playwright() as p:
        b = await p.chromium.connect_over_cdp("http://localhost:9222")
        ctx = b.contexts[0]
        ses = ""
        for pg in ctx.pages:
            m = re.search(r"[?&]ses=([a-f0-9]{16,})", pg.url)
            if m: ses = m.group(1); break
        for hid in ["7631193", "1518627", "16305106"]:
            body = await (await ctx.request.get(URL.format(h=hid, s=ses), timeout=20000)).text()
            flex = body.count("Flexible")
            words = sorted(set(re.findall(r"(Flexible|Non-refundable|Moderate|Strict|Fully flexible)", body)))
            # any 'X day' near free cancellation
            days = re.findall(r'free of charge until (\d+) day', body, re.I)
            # the rendered policy might be a 'title' or 'name' value
            titles = re.findall(r'"(?:title|policy_name|label)":"((?:Flexible|Non-refundable|Moderate|Strict)[^"]{0,30})"', body)
            print(f"{hid}: Flexible_count={flex} words={words} freeDays={days[:3]} titles={titles[:3]}")
asyncio.run(main())
