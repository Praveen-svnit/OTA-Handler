# BDC Hygiene App

A small **local** app to pull Booking.com (BDC) hygiene data straight into the
**BDC Hygiene** Google Sheet — fast, from your own logged-in Chrome.

It runs on your PC (it needs your trusted Booking login). Everything is in this
one folder, so you can zip it and share it with the team.

## First-time setup
1. Make sure **Python (Anaconda)** is installed.
2. Keep this whole folder together. `service_account.json` (the Google key) must
   be in it — it's what lets the app write to the sheet.
3. Double-click **`Start Hygiene App.bat`**. First run installs dependencies
   (1–2 min); after that it starts instantly and opens the control panel in your
   browser (`http://localhost:8765`).
   - *(Tip: right-click the .bat → Send to → Desktop, to get a one-click icon.)*

## Daily use
1. Double-click **`Start Hygiene App.bat`** — the control panel opens.
2. Click **“Open Booking & log in”** → a Chrome window opens; log into
   Booking.com there (only when asked). The panel shows **“Booking session ready ✓”**.
3. Click **Run** next to a scraper (e.g. **Review & Rating**). Watch the progress
   bar; results land in the sheet.
   - Use the **Test limit** box (e.g. `50`) to try a small batch first.

## Scrapers
- **Review & Rating** — live (review score + count).
- Genius, Preferred, Performance Score, Top Promotion, Commission %, Search
  Performance, Property Page Score — coming, one at a time.

Each scraper only writes its own columns, so running one never disturbs the others.

## Sharing with the team
Zip this folder (you can skip `.venv`, `__pycache__`, `.deps-installed`) and send
it. Each teammate needs Python; they double-click `Start Hygiene App.bat`, click
**Open Booking & log in**, and they're set. The Google key travels in the folder.

## Notes
- Nothing is public; the panel only runs at `localhost` on your machine.
- If a scrape says the session needs re-verifying, just complete Booking's
  verification in the Chrome window and run again.
