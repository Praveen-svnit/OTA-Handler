"""
Discovery probe for the 'Contact No.' scraper (main contact person's phone).

Run it with your logged-in Chrome already open (the app's "Open Booking & log
in" button, or any chrome started with --remote-debugging-port=9222). It tries
several candidate extranet endpoints for a few hotel IDs and prints, per URL:
  - whether the response stayed on admin.booking.com (i.e. session is valid)
  - whether it looks like JSON
  - any JSON keys that mention phone / mobile / contact, with their values
  - the first few phone-shaped strings found

Paste the output back so we can wire _fetch_contact to the right endpoint+key.
"""

import asyncio, json, re, sys
try: sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception: pass
from playwright.async_api import async_playwright

# Edit these to a few of YOUR own hotel IDs if these aren't in your sheet.
HOTEL_IDS = ["7631193", "1518627", "16305106"]

CANDIDATES = [
    "https://admin.booking.com/fresa/extranet/contacts/get_contacts?hotel_id={h}&lang=xu&ses={s}",
    "https://admin.booking.com/fresa/extranet/contacts/get_page_data?hotel_id={h}&lang=xu&ses={s}",
    "https://admin.booking.com/fresa/extranet/contact/get_contacts?hotel_id={h}&lang=xu&ses={s}",
    "https://admin.booking.com/hotel/hoteladmin/extranet_ng/manage/property_contacts.html?hotel_id={h}&lang=xu&ses={s}",
    "https://admin.booking.com/hotel/hoteladmin/extranet_ng/manage/contact_details.html?hotel_id={h}&lang=xu&ses={s}",
]

PHONE_RE = re.compile(r'(\+?\d[\d\-\s().]{6,}\d)')
KEYVAL_RE = re.compile(r'"([A-Za-z_]*(?:phone|mobile|contact|tel)[A-Za-z_]*)"\s*:\s*"([^"]*)"',
                       re.IGNORECASE)


async def main():
    async with async_playwright() as p:
        b = await p.chromium.connect_over_cdp("http://localhost:9222")
        ctx = b.contexts[0]
        ses = ""
        for pg in ctx.pages:
            m = re.search(r"[?&]ses=([a-f0-9]{16,})", pg.url)
            if m:
                ses = m.group(1); break
        if not ses:
            print("No session token found — log into Booking.com in the Chrome window first.")
            return
        print(f"Using ses={ses[:8]}…\n")

        for hid in HOTEL_IDS:
            print(f"================ hotel_id={hid} ================")
            for tmpl in CANDIDATES:
                url = tmpl.format(h=hid, s=ses)
                short = tmpl.split("?")[0].replace("https://admin.booking.com", "")
                try:
                    r = await ctx.request.get(url, timeout=20000)
                    body = await r.text()
                except Exception as e:
                    print(f"  [ERR ] {short}  ({e})")
                    continue
                on_admin = "admin.booking.com" in r.url
                is_json = body.lstrip().startswith(("{", "["))
                keys = KEYVAL_RE.findall(body)[:8]
                phones = [m for m in PHONE_RE.findall(body)][:5]
                tag = "JSON" if is_json else "html"
                sign = "" if on_admin else "  <-- BOUNCED TO SIGN-IN"
                print(f"  [{tag} ] {short}  len={len(body)}{sign}")
                if keys:
                    print(f"         keys: {keys}")
                if phones:
                    print(f"         phones: {phones}")
            print()

asyncio.run(main())
